package com.sstudio.submission_belajar_fundamental_aplikasi_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
